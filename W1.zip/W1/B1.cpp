#include <iostream>
#include <stdio.h>
#include <ctype.h>
using namespace std;

/*
Nguyễn Văn Diên - 16022428
1. Viết chương trình nhập chuỗi ký tự từ bàn phím và xuất ra số ký tự là chữ cái,
 số ký tự là số và số ký tự là các ký hiệu.
*/
int main() {
	string s;
	printf("Nhap chuoi ky tu:\n");
	getline(std::cin, s);
    int c_alp=0, c_num=0, c_sym=0;
    for (int i = 0; i<s.size(); i++){
        if (isalpha(s[i])){
            c_alp++;
        } else if (isdigit(s[i])){
            c_num++;
        } else if (!isspace(s[i])){
            c_sym++;
        }
    }

    printf("So ky tu la chu: %d\n",c_alp);
    printf("So ky tu la so: %d\n",c_num);
    printf("So ky tu la ky hieu: %d\n",c_sym);
	return 0;
}
