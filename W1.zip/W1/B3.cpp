#include <iostream>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
using namespace std;

/*
Nguyễn Văn Diên - 16022428
3. Viết chương trình đọc dữ liệu từ một file text và lưu các ký tự là chữ cái sang một file khác.
*/
int main() {
	string s,sf;
	printf("Nhap ten file:\n");
	getline(std::cin, sf);

    ifstream fi(sf.c_str(), ios::in);
    ofstream fo(("out_"+sf).c_str(), ios::out);

    while ( getline(fi, s) ){
        for (int i = 0; i<s.size(); i++){
            if (isalpha(s[i])){
                fo << s[i];
            }
        }
        fo << endl;
    }

    fo.close();
    fi.close();

	return 0;
}
