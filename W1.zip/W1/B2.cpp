#include <iostream>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
using namespace std;

/*
Nguyễn Văn Diên - 16022428
2. Viết chương trình nhập tên file cần tạo mới và các chuỗi ký tự từ bàn phím cho đến khi nhập ký tự kết thúc.
 Lưu các chuỗi ký tự đã nhập vào file được tạo mới và xuất kích thước file ra màn hình.
*/
int main() {
	string s,sf;
	printf("Nhap ten file:\n");
	getline(std::cin, sf);

    ofstream fo(sf.c_str(), ios::out);
    printf("Nhap chuoi ky tu:\n");

    do {
        getline(std::cin, s);
        if(!s.empty()) { fo << s << endl; }
    } while (!s.empty());
    fo.close();

    ifstream fi(sf.c_str(), ios::binary);
    fi.seekg(0, ios::end);
    printf("Kich thuoc file: %d bytes\n",fi.tellg());
    fi.close()

	return 0;
}
