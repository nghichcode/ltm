#include <iostream>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
using namespace std;

/*
Nguyễn Văn Diên - 16022428
4. Viết chương trình đọc dữ liệu từ một file ảnh và lưu dữ liệu đó sang một file khác.
 Sử dụng hàm  md5 hoặc md5sum để kiểm tra xem dữ liệu của 2 file có trùng nhau không.
*/
int main() {
	string s,sf;
	printf("Nhap ten file:\n");
	getline(std::cin, sf);

    ifstream fi(sf.c_str(), ios::in|ios::binary);
    ofstream fo(("out_"+sf).c_str(), ios::out|ios::binary);

    fo << fi.rdbuf();

    fo.close();
    fi.close();

	return 0;
}
